# Examples - MII Implementation Guide Demo Module v2026.0.0

* [**Table of Contents**](toc.md)
* **Examples**

## Examples

 This page includes translations from the original source language in which the guide was authored. Information on these translations and instructions on how to provide feedback on the translations can be found [here](translationinfo.html). 

> **Template placeholder.** Replace this with your module's content. This is the recommended English supplement of the German default page.

### Examples

Example instances of the module. The template ships the synthetic example [Max Mustermann-Testpatient](Patient-ExamplePatientInstance.md).

