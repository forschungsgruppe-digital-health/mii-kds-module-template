# de.medizininformatikinitiative.kerndatensatz.demo#2026.0.0: MII Implementation Guide Demo Module(de)

## Pages

* [Home](index.md)
* [Must Support](must-support.md)
* [Downloads](downloads.md)
* [Guidance for Implementers](implementer-guidance.md)
* [General Requirements](general-requirements.md)
* [Metadata Overview](metadata.md)
* [Datasets and Descriptions](datasets-and-descriptions.md)
* [Conformance](conformance.md)
* [Search Parameters and Operations](search-parameters-and-operations.md)
* [Profiles and Extensions](profiles-and-extensions.md)
* [UML Diagrams](uml-diagrams.md)
* [Terminology](terminology.md)
* [Guidance for Researchers](researcher-guidance.md)
* [Capability Statements](capability-statements.md)
* [Changelog](changes.md)
* [Versioning](version-history.md)
* [Translation Information](translationinfo.md)
* [Examples](examples.md)
* [Guidance](guidance.md)
* [Handling Missing Data](missing-data.md)
* [Artifacts Summary](artifacts.md)
* [Logical Models](logical-models.md)

## Resources

### Resource Profiles

* [Beispiel-Patient (Vorlage)](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Demo Module](ImplementationGuide-mii-ig-demo.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)
