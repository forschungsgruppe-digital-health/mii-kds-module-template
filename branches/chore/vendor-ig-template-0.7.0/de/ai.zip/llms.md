# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-draft.1: MII Implementation Guide Module Template(de)

## Pages

* [Startseite](index.md)
* [Beispiele](examples.md)
* [Artefakt-Rendering (Demo)](rendering-artifacts.md)
* [Datensätze und Beschreibungen](datasets-and-descriptions.md)
* [Terminologie](terminology.md)
* [Konformität](conformance.md)
* [Umgang mit fehlenden Daten](missing-data.md)
* [Versionierung](version-history.md)
* [Anleitung für Forschende](researcher-guidance.md)
* [Metadaten](metadata.md)
* [Anleitung für Implementierende](implementer-guidance.md)
* [Must-Support](must-support.md)
* [Artefaktübersicht](artifacts.md)
* [Hinweise zur Übersetzung](translationinfo.md)
* [Änderungshistorie](changes.md)
* [Logische Modelle](logical-models.md)
* [Anleitung](guidance.md)
* [Allgemeine Anforderungen](general-requirements.md)
* [Downloads](downloads.md)
* [Sicherheit und Datenschutz](security-and-privacy.md)
* [CapabilityStatements](capability-statements.md)
* [Suchparameter und Operationen](search-parameters-and-operations.md)
* [UML-Diagramme](uml-diagrams.md)
* [Profile und Extensions](profiles-and-extensions.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)
