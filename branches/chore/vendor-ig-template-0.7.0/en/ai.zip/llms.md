# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-draft.1: MII Implementation Guide Module Template(en)

## Pages

* [Home](index.md)
* [Examples](examples.md)
* [Rendering Artifacts (demo)](rendering-artifacts.md)
* [Datasets and Descriptions](datasets-and-descriptions.md)
* [Terminology](terminology.md)
* [Conformance](conformance.md)
* [Handling Missing Data](missing-data.md)
* [Versioning](version-history.md)
* [Guidance for Researchers](researcher-guidance.md)
* [Metadata Overview](metadata.md)
* [Guidance for Implementers](implementer-guidance.md)
* [Must Support](must-support.md)
* [Artifacts Summary](artifacts.md)
* [Translation Information](translationinfo.md)
* [Changelog](changes.md)
* [Logical Models](logical-models.md)
* [Guidance](guidance.md)
* [General Requirements](general-requirements.md)
* [Downloads](downloads.md)
* [Security and Privacy](security-and-privacy.md)
* [Capability Statements](capability-statements.md)
* [Search Parameters and Operations](search-parameters-and-operations.md)
* [UML Diagrams](uml-diagrams.md)
* [Profiles and Extensions](profiles-and-extensions.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)
