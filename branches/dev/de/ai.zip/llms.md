# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-draft.1: MII Implementation Guide Module Template(de)

## Pages

* [Startseite](index.md)
* [Downloads](downloads.md)
* [Hinweise zur Übersetzung](translationinfo.md)
* [CapabilityStatements](capability-statements.md)
* [Anleitung](guidance.md)
* [Allgemeine Anforderungen](general-requirements.md)
* [Änderungshistorie](changes.md)
* [Umgang mit fehlenden Daten](missing-data.md)
* [Must-Support](must-support.md)
* [Datensätze und Beschreibungen](datasets-and-descriptions.md)
* [Anleitung für Implementierende](implementer-guidance.md)
* [Versionierung](version-history.md)
* [Logische Modelle](logical-models.md)
* [Suchparameter und Operationen](search-parameters-and-operations.md)
* [Anleitung für Forschende](researcher-guidance.md)
* [Artefakt-Rendering (Demo)](rendering-artifacts.md)
* [Beispiele](examples.md)
* [Artefaktübersicht](artifacts.md)
* [Terminologie](terminology.md)
* [Konformität](conformance.md)
* [Sicherheit und Datenschutz](security-and-privacy.md)
* [Metadaten](metadata.md)
* [Profile und Extensions](profiles-and-extensions.md)
* [UML-Diagramme](uml-diagrams.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)
