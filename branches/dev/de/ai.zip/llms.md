# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-draft.1: MII Implementation Guide Module Template(de)

## Pages

* [Startseite](index.md)
* [Hinweise zur Übersetzung](translationinfo.md)
* [Logische Modelle](logical-models.md)
* [Sicherheit und Datenschutz](security-and-privacy.md)
* [UML-Diagramme](uml-diagrams.md)
* [Allgemeine Anforderungen](general-requirements.md)
* [Konformität](conformance.md)
* [Änderungshistorie](changes.md)
* [Artefakt-Rendering (Demo)](rendering-artifacts.md)
* [Versionierung](version-history.md)
* [Profile und Extensions](profiles-and-extensions.md)
* [Downloads](downloads.md)
* [Artefaktübersicht](artifacts.md)
* [Anleitung für Implementierende](implementer-guidance.md)
* [CapabilityStatements](capability-statements.md)
* [Suchparameter und Operationen](search-parameters-and-operations.md)
* [Beispiele](examples.md)
* [Umgang mit fehlenden Daten](missing-data.md)
* [Must-Support](must-support.md)
* [Metadaten](metadata.md)
* [Datensätze und Beschreibungen](datasets-and-descriptions.md)
* [Anleitung](guidance.md)
* [Anleitung für Forschende](researcher-guidance.md)
* [Terminologie](terminology.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)
