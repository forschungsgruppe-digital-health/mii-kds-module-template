# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-draft.1: MII Implementation Guide Module Template(de)

## Pages

* [Startseite](index.md)
* [Hinweise zur Übersetzung](translationinfo.md)
* [Logische Modelle](logical-models.md)
* [Sicherheit und Datenschutz](security-and-privacy.md)
* [UML-Diagramme](uml-diagrams.md)
* [Operationen](operations.md)
* [Änderungshistorie](changes.md)
* [Artefakt-Rendering (Demo)](rendering-artifacts.md)
* [Versionierung](version-history.md)
* [Suchparameter](search-parameters.md)
* [Downloads](downloads.md)
* [Artefaktübersicht](artifacts.md)
* [Anleitung für Implementierende](implementer-guidance.md)
* [CapabilityStatements](capability-statements.md)
* [Beispiele](examples.md)
* [Profile](profiles.md)
* [ValueSets](value-sets.md)
* [Metadaten-Übersicht](metadata.md)
* [CodeSystems](code-systems.md)
* [Anleitung](guidance.md)
* [Anleitung für Forschende](researcher-guidance.md)
* [Extensions](extensions.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)
