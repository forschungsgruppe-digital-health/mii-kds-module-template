# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-draft.1: MII Implementation Guide Module Template(en)

## Pages

* [Home](index.md)
* [Downloads](downloads.md)
* [Translation Information](translationinfo.md)
* [Capability Statements](capability-statements.md)
* [Guidance](guidance.md)
* [General Requirements](general-requirements.md)
* [Changelog](changes.md)
* [Handling Missing Data](missing-data.md)
* [Must Support](must-support.md)
* [Datasets and Descriptions](datasets-and-descriptions.md)
* [Guidance for Implementers](implementer-guidance.md)
* [Versioning](version-history.md)
* [Logical Models](logical-models.md)
* [Search Parameters and Operations](search-parameters-and-operations.md)
* [Guidance for Researchers](researcher-guidance.md)
* [Rendering Artifacts (demo)](rendering-artifacts.md)
* [Examples](examples.md)
* [Artifacts Summary](artifacts.md)
* [Terminology](terminology.md)
* [Conformance](conformance.md)
* [Security and Privacy](security-and-privacy.md)
* [Metadata Overview](metadata.md)
* [Profiles and Extensions](profiles-and-extensions.md)
* [UML Diagrams](uml-diagrams.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)
