# Anleitung für Forschende - MII Implementation Guide Module Template v2026.0.0

* [**Inhaltsverzeichnis**](toc.md)
* [**Anleitung**](guidance.md)
* **Anleitung für Forschende**

## Anleitung für Forschende

 Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.md). 

### Anleitung für Forschende

Hinweise für Forschende, die die Daten des Moduls **Module Template** für Forschungszwecke nutzen — z. B. welche Datenelemente für welche Fragestellungen relevant sind und wie sie interpretiert werden.

> [TODO: Beschreiben Sie die forschungsrelevanten Aspekte des Moduls.]

