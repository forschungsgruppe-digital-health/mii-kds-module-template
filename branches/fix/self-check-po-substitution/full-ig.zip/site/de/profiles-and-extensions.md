# Profile und Extensions - MII Implementation Guide Module Template v2026.0.0

* [**Inhaltsverzeichnis**](toc.md)
* **Profile und Extensions**

## Profile und Extensions

 Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.md). 

Diese Seite führt die FHIR-Profile und Extensions des Moduls **Module Template** auf. Die Vorlage enthält als Ausgangspunkt ein minimales Beispielprofil, [Beispiel-Patient](StructureDefinition-example-patient.md) — ersetzen Sie es durch die Profile Ihres Moduls (Namenskonvention `MII_PR_<Modul>_<Name>`, siehe `docs/recipes/add-a-profile.md` in diesem Repository, und die MII-Namenskonventionen).

> [TODO: Beschreiben Sie die Profile Ihres Moduls und ihre Beziehungen. Der IG-Publisher erzeugt die technischen Detailseiten automatisch.]

