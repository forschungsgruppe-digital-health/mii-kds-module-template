# Translation Information - MII Implementation Guide Module Template v2026.0.0

* [**Table of Contents**](toc.md)
* **Translation Information**

## Translation Information

 Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.html). 

### Übersetzungsinformationen

Dieser Leitfaden ist **englischsprachig** (Standardsprache); **Deutsch** ist die Übersetzung. Englisch ist damit sowohl die Basis-Darstellung des Leitfadens als auch die `/en/`-Darstellung; über den Sprachumschalter oben rechts wechseln Sie zwischen `/en/` und `/de/`.

Übersetzte Seiten liegen unter `input/translations/de/pagecontent/` (gleicher Dateiname wie die englische Seite); Ressourcen-Übersetzungen als `.po`-Dateien unter `input/translations/de/`. Details: [add-translation Rezept](../docs/recipes/add-translation.md).

> [TODO: Vermerken Sie, welche Teile des Moduls bereits ins Deutsche übersetzt sind.]

