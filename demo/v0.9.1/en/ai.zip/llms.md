# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-template.0.9.1: MII Implementation Guide Module Template(en)

## Pages

* [Home](index.md)
* [Examples](examples.md)
* [Rendering Artifacts (demo)](rendering-artifacts.md)
* [Value Sets](value-sets.md)
* [Code Systems](code-systems.md)
* [Versioning](version-history.md)
* [Extensions](extensions.md)
* [Guidance for Researchers](researcher-guidance.md)
* [Metadata Overview](metadata.md)
* [Guidance for Implementers](implementer-guidance.md)
* [Profiles](profiles.md)
* [Artifacts Summary](artifacts.md)
* [Search Parameters](search-parameters.md)
* [Translation Information](translationinfo.md)
* [Changelog](changes.md)
* [Logical Models](logical-models.md)
* [Operations](operations.md)
* [Guidance](guidance.md)
* [Downloads](downloads.md)
* [Security and Privacy](security-and-privacy.md)
* [Capability Statements](capability-statements.md)
* [UML Diagrams](uml-diagrams.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)
