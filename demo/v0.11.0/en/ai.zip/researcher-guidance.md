# Guidance for Researchers - MII Implementation Guide Module Template v2027.0.0-template.0.11.0

* [**Table of Contents**](toc.md)
* [**Guidance**](guidance.md)
* **Guidance for Researchers**

## Guidance for Researchers

> **Optional page (0..1).** The KDS module menu lists this page as **optional**. Decide for your module: **keep** it — fill it in and delete this banner and the `OPTIONAL-PAGE` marker comment (in this file AND the German mirror) — or **remove** it, following the per-entry procedure in [`docs/optional-pages.md`](https://github.com/medizininformatik-initiative/mii-kds-module-template/blob/main/docs/optional-pages.md) of this repository. A release must not ship with this banner (convention check M9).

### Guidance for Researchers

Guidance for researchers using the data of the **Module Template** module for research purposes — e.g. which data elements are relevant to which research questions, and how they are to be interpreted.

> [TODO: Describe the research-relevant aspects of your module.]

