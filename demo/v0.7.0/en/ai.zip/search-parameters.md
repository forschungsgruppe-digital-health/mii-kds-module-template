# Search Parameters - MII Implementation Guide Module Template v2027.0.0-template.0.7.0

* [**Table of Contents**](toc.md)
* **Search Parameters**

## Search Parameters

> **Optional page (0..1).** The MII module menu lists this page as **optional**. Decide for your module: **keep** it — fill it in and delete this banner and the `OPTIONAL-PAGE` marker comment (in this file AND the German mirror) — or **remove** it, following the per-entry procedure in `docs/optional-pages.md` of this repository. A release must not ship with this banner (convention check M9).

### Search Parameters

This page lists the module-specific FHIR search parameters of the **Module Template** module (naming convention `MII_SP_<Module>_<Name>`), where defined. Cross-module search parameters are defined by the MII Meta module.

> [TODO: List the search parameters — or remove this page if your module defines none.]

