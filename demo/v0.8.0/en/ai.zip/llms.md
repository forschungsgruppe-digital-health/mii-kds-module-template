# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-template.0.8.0: MII Implementation Guide Module Template(en)

## Pages

* [Home](index.md)
* [Translation Information](translationinfo.md)
* [Logical Models](logical-models.md)
* [Security and Privacy](security-and-privacy.md)
* [UML Diagrams](uml-diagrams.md)
* [Operations](operations.md)
* [Changelog](changes.md)
* [Rendering Artifacts (demo)](rendering-artifacts.md)
* [Versioning](version-history.md)
* [Search Parameters](search-parameters.md)
* [Downloads](downloads.md)
* [Artifacts Summary](artifacts.md)
* [Guidance for Implementers](implementer-guidance.md)
* [Capability Statements](capability-statements.md)
* [Examples](examples.md)
* [Profiles](profiles.md)
* [Value Sets](value-sets.md)
* [Metadata Overview](metadata.md)
* [Code Systems](code-systems.md)
* [Guidance](guidance.md)
* [Guidance for Researchers](researcher-guidance.md)
* [Extensions](extensions.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)
