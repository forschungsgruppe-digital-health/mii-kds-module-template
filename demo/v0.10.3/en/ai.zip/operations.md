# Operations - MII Implementation Guide Module Template v2027.0.0-template.0.10.3

* [**Table of Contents**](toc.md)
* **Operations**

## Operations

> **Optional page (0..1).** The KDS module menu lists this page as **optional**. Decide for your module: **keep** it — fill it in and delete this banner and the `OPTIONAL-PAGE` marker comment (in this file AND the German mirror) — or **remove** it, following the per-entry procedure in [`docs/optional-pages.md`](https://github.com/medizininformatik-initiative/mii-kds-module-template/blob/main/docs/optional-pages.md) of this repository. A release must not ship with this banner (convention check M9).

### Operations

This page lists the FHIR operations defined by the **Module Template** module (naming convention `MII_OD_<Module>_<Name>`), where defined.

> [TODO: List the operations with their invocation contexts — or remove this page if your module defines none.]

