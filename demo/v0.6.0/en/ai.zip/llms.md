# de.medizininformatikinitiative.kerndatensatz.template#2027.0.0-template.0.6.0: MII Implementation Guide Module Template(en)

## Pages

* [Home](index.md)
* [Translation Information](translationinfo.md)
* [Logical Models](logical-models.md)
* [Security and Privacy](security-and-privacy.md)
* [UML Diagrams](uml-diagrams.md)
* [General Requirements](general-requirements.md)
* [Conformance](conformance.md)
* [Changelog](changes.md)
* [Rendering Artifacts (demo)](rendering-artifacts.md)
* [Versioning](version-history.md)
* [Profiles and Extensions](profiles-and-extensions.md)
* [Downloads](downloads.md)
* [Artifacts Summary](artifacts.md)
* [Guidance for Implementers](implementer-guidance.md)
* [Capability Statements](capability-statements.md)
* [Search Parameters and Operations](search-parameters-and-operations.md)
* [Examples](examples.md)
* [Handling Missing Data](missing-data.md)
* [Must Support](must-support.md)
* [Metadata Overview](metadata.md)
* [Datasets and Descriptions](datasets-and-descriptions.md)
* [Guidance](guidance.md)
* [Guidance for Researchers](researcher-guidance.md)
* [Terminology](terminology.md)

## Resources

### Resource Profiles

* [Example Patient — template starter](StructureDefinition-example-patient.md)

### ImplementationGuides

* [MII Implementation Guide Module Template](ImplementationGuide-mii-ig-template.md)

### Parameters

* [mii-param-template-manifest](Parameters-mii-param-template-manifest.md)

### Examples

* [ExamplePatientInstance (Patient)](Patient-ExamplePatientInstance.md)
